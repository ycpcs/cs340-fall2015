# Introduction to clojure-review2

TODO: write [great documentation](http://jacobian.org/writing/great-documentation/what-to-write/)

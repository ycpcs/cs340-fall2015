(ns cs340-exam2.core-test
  (:require [clojure.test :refer :all]
            [cs340-exam2.core :refer :all]))

(deftest swap-pair-test
  (testing "swap-pair"
    (is (= [:b :a] (swap-pair [:a :b])))
    (is (= ["world!" "Hello"] (swap-pair ["Hello" "world!"])))
    (is (= [:xyz 42] (swap-pair [42 :xyz])))
    ))

(deftest swap-all-pairs-test
  (testing "swap-all-pairs"
    (is (= [[:b :a] [:d :c]] (swap-all-pairs [[:a :b] [:c :d]])))
    (is (= [[2 "apples"] [3 "pears"] [4 "oranges"]]
           (swap-all-pairs [["apples" 2] ["pears" 3] ["oranges" 4]])))
    (is (= [] (swap-all-pairs [])))))

(deftest add-to-all-test
  (testing "add-to-all"
    (is (= [11 12 13 14 15] (add-to-all [1 2 3 4 5] 10)))
    (is (= [15 6 7 8 11] (add-to-all [9 0 1 2 5] 6)))
    (is (= [] (add-to-all [] 99)))
    ))

;   (my-interleave  [88] [:a :b :c :d]) => [88 :a :b :c :d]
(deftest my-interleave-test
  (testing "my-interleave"
    (is (= [1 2 3 4 5 6] (my-interleave [1 3 5] [2 4 6])))
    (is (= [:ham :and :beans] (my-interleave [:ham :beans] [:and])))
    (is (= ["hut" 1 "hut" 2] (my-interleave ["hut" "hut"] [1 2])))
    (is (= [:x :y :z] (my-interleave [] [:x :y :z])))
    (is (= [42 121 37] (my-interleave [42 121 37] [])))
    (is (= [] (my-interleave [] [])))
    (is (= [:a 88 :b :c :d] (my-interleave [:a :b :c :d] [88])))
    (is (= [88 :a :b :c :d] (my-interleave  [88] [:a :b :c :d])))
    ))

(deftest sum-all-nested-test
  (testing "sum-all-nested"
    (is (= 6 (sum-all-nested [1 2 3])))
    (is (= 17 (sum-all-nested [9 [0 [1 [2] 5]]])))
    (is (= 14 (sum-all-nested [[[[[14]]]]])))
    (is (= 7 (sum-all-nested [[[[] []] [] [[7]]] []])))
    (is (= 0 (sum-all-nested [])))
    ))
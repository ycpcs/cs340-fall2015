(ns cs340-exam2.core)

; Function 1 [25 points].
; Note: for functions returning sequences, it doesn't matter what
; kind of sequence you return as long as the sequence contains
; the correct values.

; Take a pair (two-element sequence) as a parameter,
; and return a sequence that contains the same values
; but in the opposite order.
;
; Hint: the "first" function returns the first element of a sequence,
; and the "second" function returns the second element of a sequence. 
;
; Examples:
;   (swap-pair [:a :b]) => [:b :a]
;   (swap-pair ["Hello" "world!"]) => ["world!" "Hello"]
;   (swap-pair [42 :xyz]) => [:xyz 42]
;
(defn swap-pair [p]
;  "OHAI!")
  [(second p) (first p)])

; Function 2 [25 points].
; Take a sequence of pairs (two-element sequences) as a parameter
; and return a sequence containing pairs containing the same
; elements as the original pairs, but in the opposite order.
;
; Requirement: use the built-in map function and your swap-pair function. 
;
; Examples:
;   (swap-all-pairs [[:a :b] [:c :d]]) => [[:b :a] [:d :c]]
;   (swap-all-pairs [["apples" 2] ["pears" 3] ["oranges" 4]])
;       => [[2 "apples"] [3 "pears"] [4 "oranges"]]
;   (swap-all-pairs []) => []
;
(defn swap-all-pairs [a-seq]
  ;"OHAI!")
  (map swap-pair a-seq))

; Function 3 [20 points].
; Take a sequence (a-seq) and a number (n) as parameters, and return
; a sequence whose values are each element of s with n added.
;
; Requirement: Implement this function using tail recursion, either
; using a helper function, or using loop/recur.  The recursion should
; be on s.  Use an accumulator parameter (suggestion: the initial
; accumulator value should be an empty vector.)
;
; Think about what would be an appropriate base case.
;
; Examples:
;   (add-to-all [1 2 3 4 5] 10) => [11 12 13 14 15]
;   (add-to-all [9 0 1 2 5] 6) => [15 6 7 8 11]
;   (add-to-all [] 99) => []
;
(defn add-to-all [a-seq n]
  ;"OHAI!"
  (loop [s a-seq
         acc []]
    (if (empty? s)
      acc
      (recur (rest s) (conj acc (+ (first s) n))))))

; Function 4 [15 points].
; Take two sequences left and right.  Return a sequence that
; interleaves the elements in left and right (first element
; of left, first element of right, second element of left,
; second element of right, etc.)
;
; As a special case, if either left or right runs out of elements
; early, use all of the remaining elements from the other sequence.
;
; Requirement: the function must be tail recursive, either with
; a helper function or using loop/recur.  Do NOT just call
; the built-in interleave function.
;
; Think about what base case would be appropriate.
;
; Examples:
;   (my-interleave [1 3 5] [2 4 6]) => [1 2 3 4 5 6]
;   (my-interleave [:ham :beans] [:and]) => [:ham :and :beans]
;   (my-interleave ["hut" "hut"] [1 2]) => ["hut" 1 "hut" 2]
;   (my-interleave [] [:x :y :z]) => [:x :y :z]
;   (my-interleave [42 121 37] []) => [42 121 37]
;   (my-interleave [] []) => []
;   (my-interleave [:a :b :c :d] [88]) => [:a 88 :b :c :d]
;   (my-interleave  [88] [:a :b :c :d]) => [88 :a :b :c :d]
;
(defn my-interleave [left right]
  ;"OHAI!"
  (loop [l left
         r right
         acc []]
    (cond
      (empty? l) (concat acc r)
      (empty? r) (concat acc l)
      :else (recur (rest l) (rest r) (conj acc (first l) (first r))))))

; Function 5 [15 points].
; Take a sequence (a-seq) as a parameter.  The sequence contains
; numbers and/or nested lists.  Each nested list (if any) contains
; numbers and/or nested lists, and so on recursively.
; (I.e., any nested sequence could contain further nested sequences,
; but any non-sequence member is guaranteed to be a number.)
;
; The function should return the sum of all of the numbers found,
; directly or indirectly.
;
; Requirement: the function must be recursive, but it does not
; need to be properly tail recursive.
;
; Suggestion: Use a helper function or a loop/recur with an accumulator.
; The accumulator should be the sum of the numbers
; found so far.  Note that for handling nested lists,
; you will probably need to make a recursive call that
; is not a tail call (i.e., calling the function by name
; rather than using the recur keyword.)
;
; Hint: you can use the sequential? predicate to test whether a
; value is a sequence.
;
; Examples:
;   (sum-all-nested [1 2 3]) => 6
;   (sum-all-nested [9 [0 [1 [2] 5]]]) => 17
;   (sum-all-nested [[[[[14]]]]]) => 14
;   (sum-all-nested [[[[] []] [] [[7]]] []]) => 7
;   (sum-all-nested []) => 0
;
(defn sum-all-nested [a-seq]
  ;"OHAI"
  (loop [s a-seq
         sum 0]
    (cond
      (empty? s) sum
      (sequential? (first s)) (let [nested-sum (sum-all-nested (first s))]
                                (recur (rest s) (+ nested-sum sum)))
      :else (recur (rest s) (+ (first s) sum)))))
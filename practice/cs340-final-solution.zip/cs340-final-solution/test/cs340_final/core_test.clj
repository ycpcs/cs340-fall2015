(ns cs340-final.core-test
  (:require [clojure.test :refer :all]
            [cs340-final.core :refer :all]))

;;   (double-it 42) => 84
;;   (double-it 0) => 0
;;   (double-it "yip") => "yipyip"
;;   (double-it :plugh) => [:plugh :plugh]
;;   (double-it []) => [[] []]
(deftest double-it-test
  (testing "double-it"
    (is (= 84 (double-it 42)))
    (is (= 0 (double-it 0)))
    (is (= "yipyip" (double-it "yip")))
    (is (= [:plugh :plugh] (double-it :plugh)))
    (is (= [[] []] (double-it [])))
    ))

;;    (double-them []) => []
;;    (double-them [17 99 "hey" :boing]) => [34 198 "heyhey" [:boing :boing]]
;;   (double-them ["oo" 9]) => ["oooo" 18]
(deftest double-them-test
  (testing "double-them"
    (is (= [] (double-them [])))
    (is (= [34 198 "heyhey" [:boing :boing]] (double-them [17 99 "hey" :boing])))
    (is (= ["oooo" 18] (double-them ["oo" 9])))
    ))

;;   (count-all-nested number? []) => 0
;;   (count-all-nested number? [1 2 :a 3]) => 3
;;   (count-all-nested string? ["hey" ["uh-huh" [4 [[[:plover "woo!"] "xyz" 44]] "yup"]]])
;;      => 5
;;   (count-all-nested keyword? [:a :b [[:c [:d 121]] :e] :f]) => 6
(deftest count-all-nested-test
  (testing "count-all-nested"
    (is (= 0 (count-all-nested number? [])))
    (is (= 3 (count-all-nested number? [1 2 :a 3])))
    (is (= 5
           (count-all-nested string? ["hey" ["uh-huh" [4 [[[:plover "woo!"] "xyz" 44]] "yup"]]])))
    (is (= 6 (count-all-nested keyword? [:a :b [[:c [:d 121]] :e] :f])))
    ))

;;   (vec->tower []) => []
;;   (vec->tower ["hey!"]) => ["hey!"]
;;   (vec->tower [1 2 3]) => [1 [2] 3]
;;   (vec->tower [:a :b :c :d :e :f :g :h]) => [:a [:b [:c [:d [] :e] :f] :g] :h]
;;   (vec->tower ["that's" "all!"]) => ["that's" [] "all!"]
(deftest vec->tower-test
  (testing "vec->tower"
    (is (= [] (vec->tower [])))
    (is (= ["hey!"] (vec->tower ["hey!"])))
    (is (= [1 [2] 3] (vec->tower [1 2 3])))
    (is (= [:a [:b [:c [:d [] :e] :f] :g] :h] (vec->tower [:a :b :c :d :e :f :g :h])))
    (is (= ["that's" [] "all!"] (vec->tower ["that's" "all!"])))
    ))
(ns cs340-final.core)

;; Note: for functions returning sequences, it doesn't matter what
;; kind of sequence you return as long as the sequence contains
;; the correct values.

;; Question 8 [20 points].
;;
;; This function takes a parameter, thing, and does the following:
;;    - if thing is a number, returns thing multiplied by 2
;;    - if thing is a string, returns a string with two concatenated copies of thing
;;    - if thing is any other kind of value, returns a sequence containing
;;      two copies of thing
;;
;; Hints:
;;    - the number? function returns true if its argument is a number, false otherwise
;;    - the string? function returns true if its argument is a string, false otherwise
;;    - the str function constructs a string containing the concatenation of its
;;      arguments
;;
;; Examples:
;;   (double-it 42) => 84
;;   (double-it 0) => 0
;;   (double-it "yip") => "yipyip"
;;   (double-it :plugh) => [:plugh :plugh]
;;   (double-it []) => [[] []]

(defn double-it [thing]
  "OHAI!")

;; Question 9 [15 points].
;;
;; This function takes a sequence parameter, a-seq, and returns a
;; sequence containing the results of applying double-it to each
;; memeber of a-seq.
;;
;; Examples:
;;   (double-them []) => []
;;   (double-them [17 99 "hey" :boing]) => [34 198 "heyhey" [:boing :boing]]
;;   (double-them ["oo" 9]) => ["oooo" 18]

(defn double-them [a-seq]
  "OHAI AGAIN!")

;; Question 10 [10 points].
;;
;; This function takes a sequence and a predicate function as parameters,
;; and returns the number of values in the original sequence **and all
;; nested sequences** for which the predicate returns
;; true.  (The predicate should only be applied directly to elements
;; that are not sequences.)
;;
;; Requirements:
;;   - do **not** call flatten or my-flatten
;;   - your solution must be recursive, but it does not
;;     need to be tail recursive
;;
;; Hints:
;;   - you can use the sequential? predicate to test a value to
;;     determine whether or not it is a sequence: e.g.,
;;
;;       (sequential? x)
;;
;;     is true if x is a sequence, false otherwise
;;
;; Examples:
;;   (count-all-nested number? []) => 0
;;   (count-all-nested number? [1 2 :a 3]) => 3
;;   (count-all-nested string? ["hey" ["uh-huh" [4 [[[:plover "woo!"] "xyz" 44]] "yup"]]])
;;      => 5
;;   (count-all-nested keyword? [:a :b [[:c [:d 121]] :e] :f]) => 6

(defn count-all-nested [pred a-seq]
  "I CAN USE FIRST-CLASS FUNCTION?")

;; Question 11 [5 points].
;; This function takes a flat vector and returns a "tower" containing
;; the elements of the vector.  A tower is a vector whose
;; contents are defined as follows, where v is the original vector:
;;
;; - The first element of v is the first element of the tower
;; - The last element of v is the last element of the tower
;; - The middle element of a tower is a tower containing the
;;   elements of v except for the first and last elements
;;
;; As a special case, if v has less than 2 elements, then just return
;; v unchanged.
;;
;; Note that your function does *not* need to be tail-recursive.
;; Any solution that works is fine.
;;
;; Hint: use the first and last functions to get the first and last
;; elements of v, and use the subvec function to get a vector
;; containing the middle elements of v.
;;
;; Examples:
;;   (vec->tower []) => []
;;   (vec->tower ["hey!"]) => ["hey!"]
;;   (vec->tower [1 2 3]) => [1 [2] 3]
;;   (vec->tower [:a :b :c :d :e :f :g :h]) => [:a [:b [:c [:d [] :e] :f] :g] :h]
;;   (vec->tower ["that's" "all!"]) => ["that's" [] "all!"]

(defn vec->tower [v]
  "KTHXBYE!")

(ns minilang.astbuilder
  (:require [minilang.lexer :as lexer])
  (:require [minilang.parser2 :as p])
  (:require [minilang.prettyprint :as pp]))

; Make a new AST node.
;
; Parameters:
;   symbol - the AST node type
;   nodes  - the value of the AST node, which must be a sequence
;            containing child nodes
;
; Returns: the AST node.
;
(defn make-node [symbol nodes]
  (if (not (sequential? nodes))
    (throw (RuntimeException. "non-sequence passed as second param of make-node"))
    (minilang.parser2.Node. symbol nodes)))

; Get a sequence containing the child nodes of given parse node.
;
; Parameters:
;    node - a parse node
;
; Returns: sequence containing the children of the parse node.
;
(defn children [node]
  (if (not (vector? (:value node)))
    (throw (RuntimeException. "Getting children of terminal node"))
    (:value node)))

; Get the nth child node of given parse node.
;
; Parameters:
;    node - a parse node
;    n     - the index of the child to get (0 for the first child, 1 for the
;            second child, etc.)
;
; Returns: the nth child
;
(defn get-child [node n]
  (nth (children node) n))

; Forward declaration for the build-ast function, useful if you
; define any helper functions that need to call build-ast.
;
(declare build-ast)

; Flatten a :statement_list node.
; The resulting AST node should have the ASTs for the statements
; that are part of the statement list as immediate children.
;
; Parameters:
;   node - a :statement_list parse node
;
; Returns: the statement list as an AST, with child statements
; as immediate children
;
(defn flatten-statement-list [node]
  (throw (RuntimeException. "TODO - implement flatten-statement-list")))

; Returns an AST node whose symbol is the same as the parse node,
; and whose children are ASTs constructed from the children of the
; parse node.
;
; Parameters:
;    node - a parse node
;
; Returns: an AST node (as described above)
;
(defn recur-on-children [node]
  (make-node (:symbol node) (map build-ast (children node))))

; Build an Abstract Syntax Tree (AST) from the specified
; parse tree.
;
; Parameters:
;    node - a parse tree
;
; Returns: the abstract syntax tree representation of the parse tree.
;
(defn build-ast [node]
  (case (:symbol node)
    :unit (recur-on-children node)
    :statement_list (flatten-statement-list node)

    ; TODO: other cases
     
    ; The default case just leaves the parse node unchanged.
    ; This is the correct behavior for identifiers, int literals,
    ; and string literals
    node))

; ----------------------------------------------------------------------
; Testing
; ----------------------------------------------------------------------

(def testprog "var a; a := 3*4;")
;(def testprog "a * (b + 3);")
;(def testprog "while (a + b) { c; d*e*4; }")
;(def testprog "if (x) { y := z*3; }")

(def parse-tree (p/parse (lexer/token-sequence (lexer/create-lexer (java.io.StringReader. testprog)))))
(def ast (build-ast parse-tree))

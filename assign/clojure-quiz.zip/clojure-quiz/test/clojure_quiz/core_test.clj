(ns clojure-quiz.core-test
  (:require [clojure.test :refer :all]
            [clojure-quiz.core :refer :all]))

(deftest add-to-all-test-1
  (testing "add-to-all on first example vector"
           (is (= [15 17 23 5 20] (add-to-all [11 13 19 1 16] 4)))))

(deftest add-to-all-test-2
  (testing "add-to-all on second example vector"
           (is (= [14 0 13 8 4] (add-to-all [17 3 16 11 7] -3)))))

(deftest add-to-all-test-3
  (testing "add-to-all on empty vector"
           (is (= [] (add-to-all [] 20)))))

(deftest count-evens-test-1
  (testing "count-evens on first example vector"
           (is (= 7 (count-evens [6 4 19 2 16 10 12 14 17 13])))))

(deftest count-evens-test-2
  (testing "count-evens on second example vector"
           (is (= 4 (count-evens [4 0 18 15 13 1 8 7 9 19])))))

(deftest count-evens-test-3
  (testing "count evens on an empty vector"
           (is (= 0 (count-evens [])))))

(deftest find-min-test-1
  (testing "find-min on list"
           (is (= 4 (find-min '(12 88 5 20 6 67 99 4 17))))))

(deftest find-min-test-2
  (testing "find-min on list (min is first element)"
           (is (= 4 (find-min '(4 12 88 5 20 6 67))))))

(deftest find-min-test-3
  (testing "find-min on list (min is last element)"
           (is (= 4 (find-min '(12 88 5 20 6 67 4))))))

(deftest find-min-test-4
  (testing "find-min on vector"
           (is (= 4 (find-min [12 88 5 20 6 67 99 4 17])))))

(deftest find-min-test-5
  (testing "find-min on vector (min is first element)"
           (is (= 4 (find-min [4 12 88 5 20 6 67])))))

(deftest find-min-test-6
  (testing "find-min on vector (min is last element)"
           (is (= 4 (find-min [12 88 5 20 6 67 4])))))

(deftest pairs-test-1
  (testing "pairs on list"
           (is (= [[:a :b] [:b :c] [:c :d]] (pairs '(:a :b :c :d))))))

(deftest pairs-test-2
  (testing "pairs on list (mixed element types)"
           (is (= [[1 :b] [:b "hello"] ["hello" [:xyzzy]]] (pairs '(1 :b "hello" [:xyzzy]))))))

(deftest pairs-test-3
  (testing "pairs on list (only two elements in list)"
           (is (= [[:foo :bar]] (pairs '(:foo :bar))))))

(deftest pairs-test-4
  (testing "pairs on vector"
           (is (= [[:a :b] [:b :c] [:c :d]] (pairs [:a :b :c :d])))))

(deftest pairs-test-5
  (testing "pairs on vector (mixed element types)"
           (is (= [[1 :b] [:b "hello"] ["hello" [:xyzzy]]] (pairs [1 :b "hello" [:xyzzy]])))))

(deftest pairs-test-6
  (testing "pairs on vector (only two elements in vector)"
           (is (= [[:foo :bar]] (pairs [:foo :bar])))))

(ns clojure-quiz.core)

; Define a clojure function that will add a specified amount to
; every number in a sequence, returning the transformed sequence
; as a result.
;
; Example invocations:
;   (add-to-all [11 13 19 1 16] 4)
;     => [15 17 23 5 20]
;   (add-to-all [17 3 16 11 7] -3)
;     => [14 0 13 8 4]
;   (add-to-all [] 20)
;     => []
;
; Note that the example invocations show a vector as a result,
; but a list would also be fine.
;
; Hint: use the built-in map function
;

; TODO: implement this for real
(defn add-to-all [a-seq value]
  "I CAN HAZ HIGHER ORDER FUNCTION?")

; Define a clojure function called count-evens that returns a
; count of how many even integers are contained in the sequence
; passed as the parameter.  You can assume that all of the
; elements in the sequence will be integers.
;
; Example invocations:
;   (count-evens [6 4 19 2 16 10 12 14 17 13])
;     => 7
;   (count-evens [4 0 18 15 13 1 8 7 9 19])
;     => 4
;   (count-evens [])
;     => 0
;

; TODO: implement this for real
(defn count-evens [a-seq]
  "<-O->")

; Define a clojure function called find-min that returns the minimum
; value of the sequence passed as the parameter.
; You may assume that the sequence will have at least one
; value in it.
;
; Example invocation:
;   (find-min '(12 88 5 20 6 67 99 4 17))
;     => 4
;

; TODO: implement this for real
(defn find-min [a-seq]
  "OHAI!")

; Define a clojure function called pairs.  It takes a sequence as
; a parameter, and returns a sequence of two-element sequences,
; where each two-element sequence is an adjacent pair of values
; from the original sequence.  The pairs should be returned in order.
; You may assume the original sequence will have at least two
; members.
;
; Example invocation:
;   (pairs '(:a :b :c :d))
;     => ((:a :b) (:b :c) (:c :d))
;
; Note that it does not matter what kind of sequence you return
; as the overall result, or what kind of sequence you use for
; the pairs.  (I.e., either lists or vectors are fine.)
;

; TODO - implement this for real
(defn pairs [a-seq]
  "KTHXBYE")
